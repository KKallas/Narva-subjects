#pragma once

bool setupCamera();
